// middleware.ts
import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // فقط نحمي مسارات /admin والـ API الداخلية تحتها
  if (pathname.startsWith('/admin')) {
    // استخرج الـ JWT المخزن (يحوي الحقول id و role)
    const token = await getToken({
      req,
      secret: process.env.NEXTAUTH_SECRET,
    });

    // إن لم يكن admin فاعِد توجيه المستخدم إلى صفحة /login
    if (!token || token.role !== 'admin') {
      const loginUrl = new URL('/login', req.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  // بخلاف ذلك، اسمح بالوصول
  return NextResponse.next();
}

// طبق middleware فقط على مسارات /admin/**
export const config = {
  matcher: ['/admin/:path*'],
};
