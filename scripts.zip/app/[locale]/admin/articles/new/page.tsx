// المسار: /app/[locale]/admin/articles/new/page.tsx
'use client';

import { useParams, useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

const ArticleEditor = dynamic(()=>import('@/app/components/ArticleEditor'), { ssr:false });

export default function NewArticlePage() {
  const params = useParams() as { locale: 'en' | 'pl' };
  const { locale } = params;
  const router = useRouter();
  const { data: session, status } = useSession();

  if (status === 'loading') {
    return <p className="p-6">Loading...</p>;
  }
  if (!session) {
    return (
      <p className="p-6 text-red-500">
        {locale==='pl'
          ? <>Musisz się <Link className="underline" href={`/${locale}/login`}>zalogować</Link>.</>
          : <>You must <Link className="underline" href={`/${locale}/login`}>login</Link>.</>}
      </p>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">
        {locale==='pl'?'Nowy artykuł':'New Article'}
      </h1>
      <ArticleEditor
        mode="create"
        locale={locale}
        onSaved={(slug)=>{
          router.push(`/${locale}/admin/articles/${slug}/edit`);
        }}
      />
    </main>
  );
}
