// app/[locale]/admin/articles/page.tsx
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { redirect } from 'next/navigation';
import clientPromise from '@/types/mongodb';
import type { Filter, ObjectId } from 'mongodb';
import type { Locale, ArticleStatus } from '@/types/core/article';
import type { PageKey } from '@/types/constants/pages';
import AdminArticlesFilters from '@/components/admin/AdminArticlesFilters';
import AdminArticlesTable   from '@/components/admin/AdminArticlesTable';

export const dynamic = 'force-dynamic';

/** ===  تعريف الأنواع محلياً === */
interface ArticleRowSummary {
  id: string;
  slug: string;
  title: string;
  pageKey: PageKey;
  locale: Locale;
  status: ArticleStatus;
  createdAt?: string;
  updatedAt?: string;
  revision: number;
}

interface ArticleListResult {
  total: number;
  items: ArticleRowSummary[];
  page: number;
  limit: number;
  hasNext: boolean;
  hasPrev: boolean;
}

interface AdminArticlesInitial {
  query: {
    page: number;
    limit: number;
    search: string;
    pageKey?: PageKey;
    status?: ArticleStatus;
    locale: Locale;
    categoryId?: string;
  };
  result: ArticleListResult;
}
/** ================================ */

interface RawArticleRow {
  _id: ObjectId;
  slug: string;
  title: Record<string, string> | string;
  page: PageKey;
  status: ArticleStatus;
  categoryId: string;
  createdAt?: Date;
  updatedAt?: Date;
}

interface PageProps {
  params: { locale: Locale };
  searchParams: {
    search?: string;
    pageKey?: string;
    status?: string;
    page?: string;
    limit?: string;
    categoryId?: string;
  };
}

const VALID_PAGES = ['multi','terra','daily'] as const;
function isPageKey(v: unknown): v is PageKey {
  return typeof v==='string' && VALID_PAGES.includes(v as any);
}
function isArticleStatus(v: unknown): v is ArticleStatus {
  return ['draft','review','scheduled','published','archived'].includes(v as string);
}
function pickLocalizedTitle(raw: RawArticleRow['title'], locale: Locale){
  if (typeof raw==='string') return raw;
  return raw[locale] ?? raw.en ?? Object.values(raw)[0] ?? '';
}

export default async function AdminArticlesPage({ params, searchParams }: PageProps) {
  const { locale } = await params;
  const session = await getServerSession(authOptions);
  if (!session) redirect(`/${locale}/login`);

  const sp = await searchParams;
  const search = (sp.search ?? '').trim();
  const rawPageKey   = sp.pageKey   ?? '';
  const rawStatus    = sp.status    ?? '';
  const rawCategory  = (sp.categoryId ?? '').trim();

  const pageNo = Math.max(1, Number(sp.page)||1);
  const limit  = Math.min(100, Math.max(5, Number(sp.limit)||20));
  const skip   = (pageNo - 1)*limit;

  const pageKey    = isPageKey(rawPageKey)   ? rawPageKey   : undefined;
  const status     = isArticleStatus(rawStatus)? rawStatus  : undefined;
  const categoryId = rawCategory || undefined;

  const filter: Filter<RawArticleRow> = {};
  if (status) filter.status = status;
  if (pageKey) filter.page   = pageKey;
  if (categoryId) filter.categoryId = categoryId;
  if (search) {
    const safe = search.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const rx = new RegExp(safe,'i');
    ;(filter as any).$or = [
      { slug: rx }, { 'title.en': rx }, { 'title.pl': rx }
    ];
  }

  const db   = (await clientPromise).db();
  const coll = db.collection<RawArticleRow>('articles');
  const [docs, total] = await Promise.all([
    coll.find(filter,{projection:{content:0}})
        .sort({createdAt:-1})
        .skip(skip).limit(limit).toArray(),
    coll.countDocuments(filter),
  ]);

  const totalPages = Math.max(1, Math.ceil(total/limit));
  const rows = docs.map(d=>({
    id: d._id.toString(),
    slug: d.slug,
    title: pickLocalizedTitle(d.title, locale),
    pageKey: d.page,
    locale,
    status: d.status,
    createdAt: d.createdAt?.toISOString(),
    updatedAt: d.updatedAt?.toISOString(),
    revision: 0,
  }));

  const result: ArticleListResult = {
    total,
    items: rows,
    page: pageNo,
    limit,
    hasNext: pageNo<totalPages,
    hasPrev: pageNo>1,
  };

  const initial: AdminArticlesInitial = {
    query: { page:pageNo, limit, search, pageKey, status, locale, categoryId },
    result
  };

  return (
    <main className="max-w-7xl mx-auto px-4 py-16 space-y-10">
      {/* … */}
      <AdminArticlesFilters initial={initial} />
      {/* … */}
      <AdminArticlesTable   initial={initial} />
    </main>
  );
}
