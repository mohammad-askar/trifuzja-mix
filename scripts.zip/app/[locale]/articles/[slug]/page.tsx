// المسار: /app/[locale]/articles/[slug]/page.tsx
import { notFound } from 'next/navigation';
import clientPromise from '@/types/mongodb';
import type { Metadata } from 'next';
import type { PageKey } from '@/types/constants/pages';

type Locale = 'en' | 'pl';

interface ArticleDoc {
  slug: string;
  page: PageKey;
  categoryId: string;
  title:    Record<string, string>;
  excerpt?: Record<string, string>;
  content?: Record<string, string>;
  coverUrl?: string;
  videoUrl?: string;
  status: 'draft' | 'published';
  createdAt: Date;
  updatedAt: Date;
  readingTime?: string;
}

/* اختيار نص حسب اللغة */
function pick(field: Record<string, string> | undefined, locale: Locale): string {
  if (!field) return '';
  return field[locale] ?? field.en ?? Object.values(field)[0] ?? '';
}

/* جلب المقال */
async function fetchArticle(slug: string): Promise<ArticleDoc | null> {
  const db = (await clientPromise).db();
  const art = await db
    .collection<ArticleDoc>('articles')
    .findOne({ slug, status: 'published' });
  return art ?? null;
}

/* ميتاداتا */
export async function generateMetadata(
  { params }: { params: Promise<{ locale: Locale; slug: string }> }
): Promise<Metadata> {
  const { slug, locale } = await params;
  const art = await fetchArticle(slug);
  if (!art) {
    return {
      title: 'Not Found | Trifuzja Mix',
      description: 'Article not found',
    };
  }

  const title   = pick(art.title, locale) || 'Article';
  const excerpt = pick(art.excerpt, locale);
  const cover   = art.coverUrl;

  return {
    title: `${title} | Trifuzja Mix`,
    description: excerpt ? excerpt.slice(0, 150) : '',
    openGraph: {
      title,
      description: excerpt ? excerpt.slice(0, 200) : '',
      images: cover ? [{ url: cover }] : undefined,
      type: 'article',
    },
    alternates: { canonical: `/${locale}/articles/${slug}` },
  };
}

/* صفحة المقال */
export default async function ArticlePage(
  { params }: { params: Promise<{ locale: Locale; slug: string }> }
) {
  const { locale, slug } = await params;
  const art = await fetchArticle(slug);
  if (!art) notFound();

  const title   = pick(art.title, locale);
  const excerpt = pick(art.excerpt, locale);
  const body    = pick(art.content, locale);

  const dateStr = new Date(art.createdAt).toLocaleDateString(
    locale === 'pl' ? 'pl-PL' : 'en-GB',
    { year: 'numeric', month: 'long', day: 'numeric' }
  );

  return (
    <article className="max-w-3xl mx-auto px-4 py-24 prose dark:prose-invert">
      {art.coverUrl && (
        <div className="mb-8 rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700">
          <img
            src={art.coverUrl}
            alt={title}
            className="w-full h-auto object-cover"
          />
        </div>
      )}

      <h1 className="mb-4">{title}</h1>

      <p className="text-sm text-zinc-500 !mt-0">
        {dateStr} • {art.page.toUpperCase()} {art.readingTime && `• ${art.readingTime}`}
      </p>

      {excerpt && (
        <p className="text-base font-medium text-zinc-600 dark:text-zinc-400 border-l-4 pl-4 border-blue-500">
          {excerpt}
        </p>
      )}

      {art.videoUrl && (
        <div className="my-8 aspect-video w-full rounded-lg overflow-hidden border border-zinc-300 dark:border-zinc-700">
          {art.videoUrl.includes('youtube') || art.videoUrl.includes('youtu.be') ? (
            <iframe
              src={art.videoUrl.replace('watch?v=', 'embed/')}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title="Video"
            />
          ) : (
            <video controls src={art.videoUrl} className="w-full h-full object-cover" />
          )}
        </div>
      )}

      {body
        ? <div className="mt-10" dangerouslySetInnerHTML={{ __html: body }} />
        : <p className="mt-10 italic text-zinc-500">No content.</p>}
    </article>
  );
}
