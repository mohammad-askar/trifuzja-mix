import Header from '@/app/components/Header'
import { Footer } from '../components/Footer';
import type { ReactNode } from 'react';

interface LocaleLayoutProps {
  children: ReactNode;
  params: { locale: string };
}

export default async function LocaleLayout({ children, params }: LocaleLayoutProps) {
  const resolvedParams = await Promise.resolve(params);
  const locale = resolvedParams.locale === 'pl' ? 'pl' : 'en';

  return (
    <>
      <Header locale={locale} />
      <main className="min-h-screen p-4 pt-20">{children}</main>
      <Footer locale={locale} />
    </>
  );
}

