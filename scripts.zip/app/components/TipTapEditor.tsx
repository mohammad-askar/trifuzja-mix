'use client';

import {
  useEffect,
  useRef,
  useCallback,
  useState,
  Dispatch,
  SetStateAction,
} from 'react';
import { useEditor, EditorContent, Editor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Image from '@tiptap/extension-image';
import Placeholder from '@tiptap/extension-placeholder';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';

import { FontSize } from './editor/extensions/FontSize';
import EditorMenuBar from './EditorMenuBar';

interface TipTapEditorProps {
  content: string;
  setContent: Dispatch<SetStateAction<string>>;
  placeholder?: string;
  minHeightPx?: number;
  theme?: 'auto' | 'light' | 'dark'; // اختياري
}

export default function TipTapEditor({
  content,
  setContent,
  placeholder = 'Start writing your article…',
  minHeightPx = 300,
  theme = 'auto',
}: TipTapEditorProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);

  // تحديد الثيم الفعلي (يمكنك لاحقاً دمجه مع context)
  const effectiveTheme =
    theme === 'auto'
      ? (typeof window !== 'undefined' &&
        document.documentElement.classList.contains('dark')
          ? 'dark'
          : 'light')
      : theme;

  const insertImage = useCallback(
    (ed: Editor, url: string, alt?: string) => {
      ed.chain().focus().setImage({ src: url, alt }).run();
    },
    [],
  );

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
      Underline,
      TextStyle,
      Color,
      FontSize,
      Link.configure({ openOnClick: true, autolink: true }),
      Image.configure({
        inline: false,
        HTMLAttributes: {
          class:
            'my-4 rounded-md mx-auto max-w-full shadow-sm border border-zinc-200 dark:border-zinc-700',
          loading: 'lazy',
          decoding: 'async',
        },
      }),
      Placeholder.configure({
        placeholder,
        includeChildren: true,
        showOnlyCurrent: false,
      }),
    ],
    content,
    onUpdate: ({ editor }) => {
      const cleaned = editor
        .getHTML()
        .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
      setContent(cleaned);
    },
    editorProps: {
      attributes: {
        class: [
          // خلفية أخف قليلاً للـ dark لتحسين التباين
          'focus:outline-none max-w-none',
          `min-h-[${minHeightPx}px]`,
          'p-4 rounded-md border',
          effectiveTheme === 'dark'
            ? 'prose prose-invert bg-zinc-900/95 border-zinc-700 text-zinc-100'
            : 'prose bg-white border-zinc-300 text-zinc-800',
          // تحسين حجم الأساس
          'prose-base',
          // ضبط ألوان الرابط
          '[&_.ProseMirror]:outline-none',
        ].join(' '),
      },
    },
    immediatelyRender: false,
  });

  // مزامنة من الخارج (عدم تكرار undo)
  useEffect(() => {
    if (!editor) return;
    if (content !== editor.getHTML()) {
      editor.commands.setContent(content, { emitUpdate: false });
    }
  }, [content, editor]);

  const handleImageFiles = async (files: FileList | null) => {
    if (!files?.length || !editor) return;
    const file = files[0];
    if (!file.type.startsWith('image/')) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Image too large (max 5MB)');
      return;
    }
    try {
      setUploading(true);
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data: { url?: string; error?: string } = await res.json();
      if (!res.ok || !data.url) throw new Error(data.error || 'Upload failed');
      insertImage(editor, data.url, file.name);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // لصق صورة من الحافظة
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      if (!editor) return;
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const it of items) {
        if (it.type.startsWith('image/')) {
          const f = it.getAsFile();
          if (f) {
            handleImageFiles({
              0: f,
              length: 1,
              item: () => f,
            } as unknown as FileList);
            e.preventDefault();
            break;
          }
        }
      }
    }
    document.addEventListener('paste', onPaste);
    return () => document.removeEventListener('paste', onPaste);
  }, [editor]);

  if (!editor) {
    return (
      <div
        className={`flex items-center justify-center h-40 rounded-md border ${
          effectiveTheme === 'dark'
            ? 'bg-zinc-900 border-zinc-700'
            : 'bg-white border-zinc-300'
        }`}
      >
        <p
          className={`text-sm ${
            effectiveTheme === 'dark' ? 'text-zinc-400' : 'text-zinc-500'
          }`}
        >
          Loading editor…
        </p>
      </div>
    );
  }

  const openImageDialog = () => fileInputRef.current?.click();

  return (
    <div
      className={[
        'rounded-lg shadow-sm border',
        effectiveTheme === 'dark'
          ? 'bg-zinc-950/90 border-zinc-700'
          : 'bg-white border-zinc-300',
      ].join(' ')}
    >
      <div
        className={[
          'flex flex-wrap items-center gap-3 border-b px-4 py-2',
          effectiveTheme === 'dark'
            ? 'border-zinc-700 bg-zinc-900/70'
            : 'border-zinc-200 bg-zinc-50',
        ].join(' ')}
      >
        <EditorMenuBar
          editor={editor}
          onInsertImage={openImageDialog}
          uploadingImage={uploading}
        />
        <span
          className={`ml-auto text-xs hidden md:inline ${
            effectiveTheme === 'dark' ? 'text-zinc-400' : 'text-zinc-500'
          }`}
        >
          Paste image (Ctrl+V)
        </span>
      </div>

      <div className="px-4 pt-2 pb-4">
        <EditorContent editor={editor} />
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        hidden
        onChange={e => handleImageFiles(e.target.files)}
      />
    </div>
  );
}
