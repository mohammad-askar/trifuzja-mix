'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import slugify from 'slugify';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import { useDropzone } from 'react-dropzone';
import Image from 'next/image';
import { PAGES, PageKey } from '@/types/constants/pages';
import type { Locale, ArticleDoc } from '@/types/core/article';

const TipTapEditor = dynamic(() => import('@/app/components/TipTapEditor'), { ssr: false });

/* ---------- Types ---------- */
interface Category {
  _id: string;
  name: Record<Locale, string>;
  page: PageKey;
}
type ArticleStatus = 'draft' | 'published';

interface ArticleEditorProps {
  mode: 'create' | 'edit';
  locale: Locale;
  defaultData?: Partial<ArticleDoc>;
  onSaved?: (slug: string) => void;
}

const schema = z.object({
  title: z.string().min(3).max(140),
  excerpt: z.string().min(10).max(400),
  page: z.enum(['multi', 'terra', 'daily'] as [PageKey, PageKey, PageKey]),
  categoryId: z.string().min(1, 'Select category'),
  videoUrl: z.string().url().optional().or(z.literal('')),
  status: z.enum(['draft', 'published']),
});
type FormValues = z.infer<typeof schema>;

/* ---------- Helpers ---------- */
const makeSlug = (t: string) => slugify(t, { lower: true, strict: true });
const readingTime = (html: string) => {
  const txt = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  const words = txt ? txt.split(' ').length : 0;
  return `${Math.max(1, Math.ceil(words / 200))} min read`;
};

export default function ArticleEditor({
  mode,
  locale,
  defaultData,
  onSaved,
}: ArticleEditorProps) {
  const effectiveMode: 'create' | 'edit' = mode ?? (defaultData?.slug ? 'edit' : 'create');
  const router = useRouter();

  /* ---------- React Hook Form ---------- */
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting, dirtyFields },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: defaultData?.title?.[locale] ?? '',
      excerpt: defaultData?.excerpt?.[locale] ?? '',
      page: defaultData?.page ?? 'multi',
      categoryId: defaultData?.categoryId ?? '',
      videoUrl: defaultData?.videoUrl ?? '',
      status: defaultData?.status ?? 'draft',
    },
  });

  /* ---------- Local State ---------- */
  const originalContent = defaultData?.content?.[locale] ?? '';
  const [content, setContent] = useState<string>(originalContent);
  const [coverUrl, setCoverUrl] = useState<string>(defaultData?.coverUrl ?? '');
  const [categories, setCategories] = useState<Category[]>([]);
  const [uploading, setUploading] = useState<boolean>(false);
  const [slug, setSlug] = useState<string>(defaultData?.slug ?? '');
  const [slugLocked] = useState<boolean>(effectiveMode === 'edit');
  const initialSlugRef = useRef<string>(defaultData?.slug ?? '');

  /* ---------- Watched Values ---------- */
  const titleValue = watch('title');
  const pageValue = watch('page');
  const statusValue = watch('status');
  const excerptValue = watch('excerpt');
  const categoryIdValue = watch('categoryId');

  /* ---------- Auto-slug (create only) ---------- */
  useEffect(() => {
    if (slugLocked) return;
    if (!titleValue) {
      setSlug('');
      return;
    }
    setSlug(makeSlug(titleValue));
  }, [titleValue, slugLocked]);

  /* ---------- Load Categories on page change ---------- */
  const loadCats = useCallback(
    async (pg: PageKey) => {
      try {
        const res = await fetch(`/api/categories?page=${pg}`);
        const data: Category[] = await res.json();
        setCategories(data);
        const current = categoryIdValue;
        if (current && !data.find(c => c._id === current)) {
          setValue('categoryId', '');
        }
      } catch {
        toast.error('Categories error');
      }
    },
    [setValue, categoryIdValue],
  );

  useEffect(() => {
    loadCats(pageValue);
  }, [pageValue, loadCats]);

  /* ---------- Cover Upload (Dropzone) ---------- */
  const onDrop = useCallback(async (files: File[]) => {
    if (!files.length) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', files[0]);
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data: { url?: string; error?: string } = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      if (!data.url) throw new Error('No URL');
      setCoverUrl(data.url);
      toast.success('Image uploaded');
    } catch (e: unknown) {
      toast.error((e as Error).message);
    } finally {
      setUploading(false);
    }
  }, []);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  /* ---------- Dirty detection & beforeunload ---------- */
  const dirty = useMemo(
    () =>
      Object.keys(dirtyFields).length > 0 ||
      content !== originalContent ||
      coverUrl !== (defaultData?.coverUrl ?? ''),
    [dirtyFields, content, originalContent, coverUrl, defaultData?.coverUrl],
  );

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (dirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [dirty]);

  /* ---------- Word Count & Readiness ---------- */
  const wordCount = useMemo(
    () => content.replace(/<[^>]+>/g, ' ').trim().split(/\s+/).filter(Boolean).length,
    [content],
  );
  const minimalReady: boolean =
    titleValue.trim().length >= 3 &&
    excerptValue.trim().length >= 10 &&
    wordCount >= 20 &&
    !!categoryIdValue;

  /* ---------- Submit Handler ---------- */
  interface SavePayload {
    slug: string;
    title: Record<string, string>;
    excerpt: Record<string, string>;
    content: Record<string, string>;
    page: PageKey;
    categoryId: string;
    coverUrl?: string;
    videoUrl?: string;
    status: ArticleStatus;
    readingTime: string;
  }

  const onSubmit = async (fv: FormValues) => {
    if (!slug) {
      toast.error('Slug empty');
      return;
    }
    if (effectiveMode === 'edit' && !initialSlugRef.current) {
      toast.error('Original slug missing');
      return;
    }

    const payload: SavePayload = {
      slug,
      title: { [locale]: fv.title },
      excerpt: { [locale]: fv.excerpt },
      content: { [locale]: content },
      page: fv.page,
      categoryId: fv.categoryId,
      coverUrl: coverUrl || undefined,
      videoUrl: fv.videoUrl?.trim() ? fv.videoUrl.trim() : undefined,
      status: fv.status,
      readingTime: readingTime(content),
    };

    try {
      const endpoint =
        effectiveMode === 'create'
          ? '/api/articles'
          : `/api/admin/articles/${initialSlugRef.current}`;
      const method = effectiveMode === 'create' ? 'POST' : 'PUT';

      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const out = await res.json();
      if (!res.ok) throw new Error(out.error || 'Server error');

      toast.success(effectiveMode === 'create' ? 'Created ✅' : 'Saved ✅');

      if (effectiveMode === 'create') {
  initialSlugRef.current = slug;
  onSaved?.(slug);
  router.push(`/${locale}/admin/articles/${slug}/edit`);
} else {
  router.refresh();
}
    } catch (e: unknown) {
      toast.error((e as Error).message);
    }
  };

  /* ---------- Delete ---------- */
  const handleDelete = async () => {
    if (effectiveMode !== 'edit') return;
    if (!confirm('Delete this article permanently?')) return;
    try {
      const res = await fetch(`/api/admin/articles/${initialSlugRef.current}`, {
        method: 'DELETE',
      });
      const out = await res.json();
      if (!res.ok) throw new Error(out.error || 'Delete failed');
      toast.success('Deleted ✅');
      router.push('/admin/articles');
      router.refresh();
    } catch (e: unknown) {
      toast.error((e as Error).message);
    }
  };

  /* ---------- Toggle Publish ---------- */
  const togglePublish = async () => {
    if (effectiveMode !== 'edit') return;
    const newStatus: ArticleStatus = statusValue === 'draft' ? 'published' : 'draft';
    setValue('status', newStatus, { shouldDirty: true });
    try {
      const res = await fetch(`/api/admin/articles/${initialSlugRef.current}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const out = await res.json();
      if (!res.ok) throw new Error(out.error || 'Status update failed');
      toast.success(
        newStatus === 'published' ? 'Published 🚀' : 'Back to draft',
      );
      router.refresh();
    } catch (e: unknown) {
      toast.error((e as Error).message);
    }
  };

  const removeImage = () => setCoverUrl('');

  /* ---------- Render ---------- */
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
      {/* Title & Excerpt */}
      <section className="space-y-4">
        <div>
          <input
            {...register('title')}
            placeholder={locale === 'pl' ? 'Tytuł artykułu' : 'Article title'}
            className="w-full rounded-md border px-4 py-2 text-lg font-medium focus:ring-2 focus:ring-blue-500 outline-none bg-white dark:bg-zinc-900"
          />
          <div className="flex justify-between mt-1">
            {errors.title && (
              <p className="text-xs text-red-600">{errors.title.message}</p>
            )}
            <p className="text-[11px] text-gray-500">{titleValue.length}/140</p>
          </div>
        </div>

        <div>
          <textarea
            {...register('excerpt')}
            rows={3}
            placeholder={locale === 'pl' ? 'Krótki opis…' : 'Short summary…'}
            className="w-full rounded-md border px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white dark:bg-zinc-900"
          />
          <div className="flex justify-between mt-1">
            {errors.excerpt && (
              <p className="text-xs text-red-600">{errors.excerpt.message}</p>
            )}
            <p className="text-[11px] text-gray-500">{excerptValue.length}/400</p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="space-y-2">
        <TipTapEditor content={content} setContent={setContent} />
        <div className="flex justify-between text-[11px] text-gray-500">
          <span>
            {wordCount} {locale === 'pl' ? 'słów' : 'words'}
          </span>
          {wordCount < 20 && (
            <span className="text-orange-600">
              {locale === 'pl'
                ? 'Dodaj więcej treści (≥20 słów).'
                : 'Add more content (≥20 words).'}
            </span>
          )}
        </div>
      </section>

      {/* Media & Meta */}
      <section className="grid gap-6 lg:grid-cols-3">
        {/* Cover + Video */}
        <div className="space-y-6 lg:col-span-1">
          <div
            {...getRootProps()}
            className={`rounded-lg border-2 border-dashed p-5 text-center cursor-pointer transition bg-white dark:bg-zinc-900 ${
              isDragActive
                ? 'border-blue-400 bg-blue-50 dark:bg-zinc-800'
                : 'border-gray-300'
            }`}
          >
            <input {...getInputProps()} />
            <p className="text-xs text-gray-600 dark:text-gray-300">
              {uploading
                ? locale === 'pl'
                  ? 'Wysyłanie…'
                  : 'Uploading…'
                : locale === 'pl'
                ? 'Kliknij lub upuść okładkę (max 5MB)'
                : 'Click or drop cover (max 5MB)'}
            </p>
            {coverUrl && (
              <div className="mt-3 space-y-2">
                <div className="relative w-full h-40 overflow-hidden rounded-md">
                  <Image
                    src={coverUrl}
                    alt={titleValue || 'cover'}
                    fill
                    sizes="(max-width:768px) 100vw, 33vw"
                    className="object-cover"
                  />
                </div>
                <button
                  type="button"
                  onClick={removeImage}
                  className="text-xs px-3 py-1 rounded border hover:bg-gray-50 dark:hover:bg-zinc-800"
                >
                  {locale === 'pl' ? 'Usuń' : 'Remove'}
                </button>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <input
              {...register('videoUrl')}
              placeholder="https://www.youtube.com/watch?v=..."
              className="w-full rounded-md border px-3 py-2 text-sm bg-white dark:bg-zinc-900"
            />
            {errors.videoUrl && (
              <p className="text-xs text-red-500">{errors.videoUrl.message}</p>
            )}
          </div>
        </div>

        {/* Page / Category / Status / Info */}
        <div className="lg:col-span-2 grid gap-6 md:grid-cols-2">
          <div className="space-y-1">
            <label className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">
              {locale === 'pl' ? 'Strona' : 'Page'}
            </label>
            <select
              {...register('page')}
              className="w-full rounded-md border px-3 py-2 bg-white dark:bg-zinc-900"
            >
              {PAGES.map(p => (
                <option key={p.key} value={p.key}>
                  {locale === 'pl' ? p.labelPl : p.labelEn}
                </option>
              ))}
            </select>
          </div>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">
                {locale === 'pl' ? 'Kategoria' : 'Category'}
              </label>
              <select
                {...register('categoryId')}
                className="w-full rounded-md border px-3 py-2 bg-white dark:bg-zinc-900"
              >
                <option value="">
                  {locale === 'pl' ? 'Wybierz' : 'Select'}
                </option>
                {categories.map(c => (
                  <option key={c._id} value={c._id}>
                    {c.name[locale] ?? c._id.slice(0, 6)}
                  </option>
                ))}
              </select>
              {errors.categoryId && (
                <p className="text-xs text-red-500 mt-1">
                  {errors.categoryId.message}
                </p>
              )}
            </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">
              {locale === 'pl' ? 'Status' : 'Status'}
            </label>
            <div className="flex gap-4 items-center text-sm">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  value="draft"
                  {...register('status')}
                  checked={statusValue === 'draft'}
                />
                {locale === 'pl' ? 'Szkic' : 'Draft'}
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  value="published"
                  {...register('status')}
                  checked={statusValue === 'published'}
                />
                {locale === 'pl' ? 'Opublikowany' : 'Published'}
              </label>
            </div>
          </div>

          <div className="space-y-1 text-[11px] text-gray-500 flex items-end">
            <div>
              <p>
                {locale === 'pl'
                  ? 'Slug generowany automatycznie.'
                  : 'Slug auto-generated.'}
              </p>
              <p>
                {locale === 'pl'
                  ? 'Dodaj treść co najmniej 20 słów.'
                  : 'Add at least 20 words of content.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Sticky Action Bar */}
      <div className="sticky bottom-0 bg-white/90 dark:bg-zinc-900/90 backdrop-blur border-t flex flex-col md:flex-row gap-3 md:items-center justify-between px-4 py-3 rounded-t-md shadow">
        <div className="flex flex-wrap items-center gap-4 text-xs text-gray-600 dark:text-gray-400">
          <span>
            {locale === 'pl' ? 'Status:' : 'Status:'}{' '}
            <strong
              className={
                statusValue === 'published'
                  ? 'text-green-600'
                  : 'text-yellow-700'
              }
            >
              {statusValue === 'published'
                ? locale === 'pl'
                  ? 'Opublikowany'
                  : 'Published'
                : locale === 'pl'
                ? 'Szkic'
                : 'Draft'}
            </strong>
          </span>
          <span>
            {locale === 'pl' ? 'Słowa:' : 'Words:'} {wordCount}
          </span>
          <span>
            {locale === 'pl' ? 'Czytanie:' : 'Reading:'} {readingTime(content)}
          </span>
          {dirty && (
            <span className="text-orange-600">
              {locale === 'pl'
                ? 'Niezapisane zmiany'
                : 'Unsaved changes'}
            </span>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {effectiveMode === 'edit' && (
            <button
              type="button"
              onClick={togglePublish}
              className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium"
            >
              {statusValue === 'draft'
                ? locale === 'pl'
                  ? 'Opublikuj'
                  : 'Publish'
                : locale === 'pl'
                ? 'Cofnij'
                : 'Unpublish'}
            </button>
          )}

          <button
            type="submit"
            disabled={isSubmitting || !minimalReady}
            className="px-5 py-2 rounded-md bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-medium"
          >
            {isSubmitting
              ? effectiveMode === 'create'
                ? locale === 'pl'
                  ? 'Tworzenie…'
                  : 'Creating…'
                : locale === 'pl'
                ? 'Zapisywanie…'
                : 'Saving…'
              : effectiveMode === 'create'
              ? locale === 'pl'
                ? 'Utwórz'
                : 'Create'
              : locale === 'pl'
              ? 'Zapisz'
              : 'Save'}
          </button>

          {effectiveMode === 'edit' && (
            <button
              type="button"
              onClick={handleDelete}
              className="px-4 py-2 rounded-md bg-red-600 hover:bg-red-700 text-white text-sm font-medium"
            >
              {locale === 'pl' ? 'Usuń' : 'Delete'}
            </button>
          )}

          {effectiveMode === 'edit' && statusValue === 'published' && (
            <a
              href={`/articles/${slug}`}
              target="_blank"
              className="px-4 py-2 rounded-md border text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-800"
            >
              {locale === 'pl' ? 'Podgląd' : 'Preview'} ↗
            </a>
          )}
        </div>
      </div>
    </form>
  );
}
