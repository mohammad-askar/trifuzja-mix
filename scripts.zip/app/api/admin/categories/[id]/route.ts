//E:\trifuzja-mix\app\api\admin\categories\[id]\route.ts
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { ObjectId } from 'mongodb';
import clientPromise from '@/types/mongodb';
import { requireAdmin } from '@/types/auth';

export async function DELETE(req: NextRequest) {
  await requireAdmin();

  const id = req.nextUrl.pathname.split('/').pop()!;
  if (!/^[0-9a-fA-F]{24}$/.test(id))
    return NextResponse.json({ error: 'Invalid id format' }, { status: 400 });

  try {
    const db  = (await clientPromise).db();
    const res = await db.collection('categories').deleteOne({ _id: new ObjectId(id) });

    if (res.deletedCount === 0)
      return NextResponse.json({ error: 'Category not found' }, { status: 404 });

    console.info('Category deleted', id);
    return new NextResponse(null, { status: 204 });
  } catch (e) {
    console.error('DELETE category error', e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
