// components/admin/AdminArticlesFilters.tsx
'use client';

import { useRouter, usePathname, useSearchParams } from 'next/navigation';
import { useState, useEffect, useCallback, useRef } from 'react';
import type { PageKey, ArticleStatus } from '@/types/core/article';

// تعريف الواجهة المحلية بدل الاستيراد من مكان آخر
interface AdminArticlesQuery {
  search?: string;
  pageKey?: PageKey;
  status?: ArticleStatus;
  locale: string;
}

interface AdminArticlesInitial {
  query: AdminArticlesQuery;
}

interface Props {
  initial: AdminArticlesInitial;
}

export default function AdminArticlesFilters({ initial }: Props) {
  const router       = useRouter();
  const pathname     = usePathname();
  const searchParams = useSearchParams();

  // نستنشق القيم مباشرة من initial.query
  const { locale, search: initSearch, pageKey: initPageKey, status: initStatus } = initial.query;

  const [search,  setSearch]  = useState<string>(initSearch ?? '');
  const [pageKey, setPageKey] = useState<'' | PageKey>(initPageKey ?? '');
  const [status,  setStatus]  = useState<'' | ArticleStatus>(initStatus ?? '');

  const labelAll = locale === 'pl' ? 'Wszystko' : 'All';
  const lastQueryRef = useRef<string>('');

  const buildParamsString = useCallback((): string => {
    const params = new URLSearchParams(searchParams?.toString() || '');

    const setOrDelete = (k: string, v: string | undefined) => {
      if (v && v.trim()) params.set(k, v.trim());
      else params.delete(k);
    };

    setOrDelete('search',  search);
    setOrDelete('pageKey', pageKey);
    setOrDelete('status',  status);
    params.delete('page');

    return params.toString();
  }, [search, pageKey, status, searchParams]);

  const pushQuery = useCallback(() => {
    const qs = buildParamsString();
    if (qs === lastQueryRef.current) return;
    lastQueryRef.current = qs;
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
  }, [buildParamsString, router, pathname]);

  // Debounce للبحث
  useEffect(() => {
    const id = setTimeout(() => {
      pushQuery();
      try {
        if (search) sessionStorage.setItem('admin-articles-search', search);
        else sessionStorage.removeItem('admin-articles-search');
      } catch {}
    }, 400);
    return () => clearTimeout(id);
  }, [search, pushQuery]);

  // فور تغيير الفلاتر الأخرى
  useEffect(() => {
    pushQuery();
  }, [pageKey, status, pushQuery]);

  // استرجاع البحث السابق من الـ sessionStorage
  useEffect(() => {
    if (!initSearch) {
      try {
        const prev = sessionStorage.getItem('admin-articles-search');
        if (prev && !search) setSearch(prev);
      } catch {}
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function resetAll() {
    setSearch('');
    setPageKey('');
    setStatus('');
    lastQueryRef.current = '';
    router.replace(pathname, { scroll: false });
  }

  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:gap-6">
      {/* Search */}
      <div className="flex-1">
        <label htmlFor="admin-search" className="block text-xs font-semibold mb-1">
          {locale === 'pl' ? 'Szukaj' : 'Search'}
        </label>
        <input
          id="admin-search"
          aria-label={locale === 'pl' ? 'Wyszukiwanie artykułów' : 'Search articles'}
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={locale === 'pl' ? 'Tytuł lub slug…' : 'Title or slug…'}
          className="w-full rounded-md border px-3 py-2 text-sm bg-white dark:bg-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Page filter */}
      <div>
        <label htmlFor="admin-page-filter" className="block text-xs font-semibold mb-1">
          {locale === 'pl' ? 'Strona' : 'Page'}
        </label>
        <select
          id="admin-page-filter"
          value={pageKey}
          onChange={e => setPageKey(e.target.value as '' | PageKey)}
          className="rounded-md border px-3 py-2 text-sm bg-white dark:bg-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">{labelAll}</option>
          <option value="multi">multi</option>
          <option value="terra">terra</option>
          <option value="daily">daily</option>
        </select>
      </div>

      {/* Status filter */}
      <div>
        <label htmlFor="admin-status-filter" className="block text-xs font-semibold mb-1">
          {locale === 'pl' ? 'Status' : 'Status'}
        </label>
        <select
          id="admin-status-filter"
          value={status}
          onChange={e => setStatus(e.target.value as '' | ArticleStatus)}
          className="rounded-md border px-3 py-2 text-sm bg-white dark:bg-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">{labelAll}</option>
          <option value="draft">{locale === 'pl' ? 'Szkic' : 'Draft'}</option>
          <option value="published">{locale === 'pl' ? 'Opublik.' : 'Published'}</option>
        </select>
      </div>

      {/* Reset */}
      <div className="flex gap-3">
        <button
          type="button"
          onClick={resetAll}
          className="h-10 px-4 rounded-md border text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {locale === 'pl' ? 'Reset' : 'Reset'}
        </button>
      </div>
    </div>
  );
}
