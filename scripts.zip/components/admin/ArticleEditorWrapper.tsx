// المسار: /components/admin/ArticleEditorWrapper.tsx
'use client';

/**
 * 🧩 مكوّن وسيط (Client) لتحميل ArticleEditor ديناميكيًا
 * يمنع مشاكل SSR للمحرر (TipTap) ويضمن أن الأنواع آمنة.
 */

import dynamic from 'next/dynamic';
import { useState } from 'react';
import type { ArticleDoc, Locale } from '@/types/core/article';

const ArticleEditor = dynamic(
  () => import('@/app/components/ArticleEditor'),
  {
    ssr: false,
    loading: () => (
      <p className="text-sm text-zinc-500">
        Loading editor…
      </p>
    ),
  },
);

/* ---------- Props ---------- */
interface ArticleEditorWrapperProps {
  mode: 'create' | 'edit';
  locale: Locale;
  defaultData?: Partial<ArticleDoc>;
  onSaved?: (slug: string) => void;
}

/* ---------- Component ---------- */
export default function ArticleEditorWrapper({
  mode,
  locale,
  defaultData,
  onSaved,
}: ArticleEditorWrapperProps) {
  // نحفظ النسخة الأولية فقط (اختياري لمنع إعادة تمرير مرجع جديد)
  const [initial] = useState<Partial<ArticleDoc> | undefined>(defaultData);

  return (
    <ArticleEditor
      mode={mode}
      locale={locale}
      defaultData={initial}
      onSaved={onSaved}
    />
  );
}
