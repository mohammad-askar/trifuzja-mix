// المسار: E:\trifuzja-mix\types\admin\index.ts

export * from '@/types/core/article';
export * from '../core/pagination';        // يحتوي PaginatedResult
